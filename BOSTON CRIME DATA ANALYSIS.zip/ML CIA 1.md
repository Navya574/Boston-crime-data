

```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
```


```python
df = pd.read_csv('C:\\Users\\D Navya\\Desktop\\Boston crimes.csv', encoding = 'latin-1')
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>INCIDENT_NUMBER</th>
      <th>OFFENSE_CODE</th>
      <th>OFFENSE_CODE_GROUP</th>
      <th>OFFENSE_DESCRIPTION</th>
      <th>DISTRICT</th>
      <th>REPORTING_AREA</th>
      <th>SHOOTING</th>
      <th>OCCURRED_ON_DATE</th>
      <th>YEAR</th>
      <th>MONTH</th>
      <th>DAY_OF_WEEK</th>
      <th>HOUR</th>
      <th>UCR_PART</th>
      <th>STREET</th>
      <th>Lat</th>
      <th>Long</th>
      <th>Location</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>I182080058</td>
      <td>2403</td>
      <td>Disorderly Conduct</td>
      <td>DISTURBING THE PEACE</td>
      <td>E18</td>
      <td>495</td>
      <td>NaN</td>
      <td>03-10-2018 20:13</td>
      <td>2018</td>
      <td>10</td>
      <td>Wednesday</td>
      <td>20</td>
      <td>Part Two</td>
      <td>ARLINGTON ST</td>
      <td>42.262608</td>
      <td>-71.121186</td>
      <td>(42.26260773, -71.12118637)</td>
    </tr>
    <tr>
      <th>1</th>
      <td>I182080053</td>
      <td>3201</td>
      <td>Property Lost</td>
      <td>PROPERTY - LOST</td>
      <td>D14</td>
      <td>795</td>
      <td>NaN</td>
      <td>30-08-2018 20:00</td>
      <td>2018</td>
      <td>8</td>
      <td>Thursday</td>
      <td>20</td>
      <td>Part Three</td>
      <td>ALLSTON ST</td>
      <td>42.352111</td>
      <td>-71.135311</td>
      <td>(42.35211146, -71.13531147)</td>
    </tr>
    <tr>
      <th>2</th>
      <td>I182080052</td>
      <td>2647</td>
      <td>Other</td>
      <td>THREATS TO DO BODILY HARM</td>
      <td>B2</td>
      <td>329</td>
      <td>NaN</td>
      <td>03-10-2018 19:20</td>
      <td>2018</td>
      <td>10</td>
      <td>Wednesday</td>
      <td>19</td>
      <td>Part Two</td>
      <td>DEVON ST</td>
      <td>42.308126</td>
      <td>-71.076930</td>
      <td>(42.30812619, -71.07692974)</td>
    </tr>
    <tr>
      <th>3</th>
      <td>I182080051</td>
      <td>413</td>
      <td>Aggravated Assault</td>
      <td>ASSAULT - AGGRAVATED - BATTERY</td>
      <td>A1</td>
      <td>92</td>
      <td>NaN</td>
      <td>03-10-2018 20:00</td>
      <td>2018</td>
      <td>10</td>
      <td>Wednesday</td>
      <td>20</td>
      <td>Part One</td>
      <td>CAMBRIDGE ST</td>
      <td>42.359454</td>
      <td>-71.059648</td>
      <td>(42.35945371, -71.05964817)</td>
    </tr>
    <tr>
      <th>4</th>
      <td>I182080050</td>
      <td>3122</td>
      <td>Aircraft</td>
      <td>AIRCRAFT INCIDENTS</td>
      <td>A7</td>
      <td>36</td>
      <td>NaN</td>
      <td>03-10-2018 20:49</td>
      <td>2018</td>
      <td>10</td>
      <td>Wednesday</td>
      <td>20</td>
      <td>Part Three</td>
      <td>PRESCOTT ST</td>
      <td>42.375258</td>
      <td>-71.024663</td>
      <td>(42.37525782, -71.02466343)</td>
    </tr>
  </tbody>
</table>
</div>




```python
print(df.shape, df.drop_duplicates().shape)
df = df.drop_duplicates()
```

    (327797, 17) (327797, 17)
    


```python
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    Int64Index: 327797 entries, 0 to 327819
    Data columns (total 17 columns):
    INCIDENT_NUMBER        327797 non-null object
    OFFENSE_CODE           327797 non-null int64
    OFFENSE_CODE_GROUP     327797 non-null object
    OFFENSE_DESCRIPTION    327797 non-null object
    DISTRICT               326023 non-null object
    REPORTING_AREA         327797 non-null object
    SHOOTING               1055 non-null object
    OCCURRED_ON_DATE       327797 non-null object
    YEAR                   327797 non-null int64
    MONTH                  327797 non-null int64
    DAY_OF_WEEK            327797 non-null object
    HOUR                   327797 non-null int64
    UCR_PART               327704 non-null object
    STREET                 316820 non-null object
    Lat                    307166 non-null float64
    Long                   307166 non-null float64
    Location               327797 non-null object
    dtypes: float64(2), int64(4), object(11)
    memory usage: 45.0+ MB
    


```python
df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>OFFENSE_CODE</th>
      <th>YEAR</th>
      <th>MONTH</th>
      <th>HOUR</th>
      <th>Lat</th>
      <th>Long</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>327797.000000</td>
      <td>327797.000000</td>
      <td>327797.000000</td>
      <td>327797.000000</td>
      <td>307166.000000</td>
      <td>307166.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>2317.932001</td>
      <td>2016.598764</td>
      <td>6.672123</td>
      <td>13.114812</td>
      <td>42.212987</td>
      <td>-70.906018</td>
    </tr>
    <tr>
      <th>std</th>
      <td>1185.012823</td>
      <td>1.009742</td>
      <td>3.253971</td>
      <td>6.292765</td>
      <td>2.173574</td>
      <td>3.515958</td>
    </tr>
    <tr>
      <th>min</th>
      <td>111.000000</td>
      <td>2015.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>-1.000000</td>
      <td>-71.178674</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>1001.000000</td>
      <td>2016.000000</td>
      <td>4.000000</td>
      <td>9.000000</td>
      <td>42.297466</td>
      <td>-71.097081</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>2907.000000</td>
      <td>2017.000000</td>
      <td>7.000000</td>
      <td>14.000000</td>
      <td>42.325552</td>
      <td>-71.077493</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>3201.000000</td>
      <td>2017.000000</td>
      <td>9.000000</td>
      <td>18.000000</td>
      <td>42.348624</td>
      <td>-71.062482</td>
    </tr>
    <tr>
      <th>max</th>
      <td>3831.000000</td>
      <td>2018.000000</td>
      <td>12.000000</td>
      <td>23.000000</td>
      <td>42.395042</td>
      <td>-1.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
df["SHOOTING"].fillna("N", inplace = True)
df["DAY_OF_WEEK"] = pd.Categorical(df["DAY_OF_WEEK"], 
              categories=['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'],
              ordered=True)
df["Lat"].replace(-1, None, inplace=True)
df["Long"].replace(-1, None, inplace=True)

df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>OFFENSE_CODE</th>
      <th>YEAR</th>
      <th>MONTH</th>
      <th>HOUR</th>
      <th>Lat</th>
      <th>Long</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>327797.000000</td>
      <td>327797.000000</td>
      <td>327797.000000</td>
      <td>327797.000000</td>
      <td>307117.000000</td>
      <td>307117.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>2317.932001</td>
      <td>2016.598764</td>
      <td>6.672123</td>
      <td>13.114812</td>
      <td>42.322295</td>
      <td>-71.082842</td>
    </tr>
    <tr>
      <th>std</th>
      <td>1185.012823</td>
      <td>1.009742</td>
      <td>3.253971</td>
      <td>6.292765</td>
      <td>0.031860</td>
      <td>0.029748</td>
    </tr>
    <tr>
      <th>min</th>
      <td>111.000000</td>
      <td>2015.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>42.232413</td>
      <td>-71.178674</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>1001.000000</td>
      <td>2016.000000</td>
      <td>4.000000</td>
      <td>9.000000</td>
      <td>42.297555</td>
      <td>-71.097189</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>2907.000000</td>
      <td>2017.000000</td>
      <td>7.000000</td>
      <td>14.000000</td>
      <td>42.325653</td>
      <td>-71.077551</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>3201.000000</td>
      <td>2017.000000</td>
      <td>9.000000</td>
      <td>18.000000</td>
      <td>42.348624</td>
      <td>-71.062563</td>
    </tr>
    <tr>
      <th>max</th>
      <td>3831.000000</td>
      <td>2018.000000</td>
      <td>12.000000</td>
      <td>23.000000</td>
      <td>42.395042</td>
      <td>-70.963676</td>
    </tr>
  </tbody>
</table>
</div>




```python
def getDate(dateStr, numChar):
    return dateStr[0:numChar]

df['DATE'] = df['OCCURRED_ON_DATE'].apply(getDate, numChar = 10)
df['YEARMONTH'] = df['OCCURRED_ON_DATE'].apply(getDate, numChar = 7)

df[['YEARMONTH', 'DATE', 'OCCURRED_ON_DATE']].head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>YEARMONTH</th>
      <th>DATE</th>
      <th>OCCURRED_ON_DATE</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>03-10-2</td>
      <td>03-10-2018</td>
      <td>03-10-2018 20:13</td>
    </tr>
    <tr>
      <th>1</th>
      <td>30-08-2</td>
      <td>30-08-2018</td>
      <td>30-08-2018 20:00</td>
    </tr>
    <tr>
      <th>2</th>
      <td>03-10-2</td>
      <td>03-10-2018</td>
      <td>03-10-2018 19:20</td>
    </tr>
    <tr>
      <th>3</th>
      <td>03-10-2</td>
      <td>03-10-2018</td>
      <td>03-10-2018 20:00</td>
    </tr>
    <tr>
      <th>4</th>
      <td>03-10-2</td>
      <td>03-10-2018</td>
      <td>03-10-2018 20:49</td>
    </tr>
  </tbody>
</table>
</div>




```python
print('Num of records: {} \nNum of events: {}'.format(df.shape[0], df["INCIDENT_NUMBER"].nunique()))
```

    Num of records: 327797 
    Num of events: 290156
    


```python
print("It  seemes like there are {} records in database per 1 crime.".format(round(df.shape[0]/df["INCIDENT_NUMBER"].nunique(),2)))
```

    It  seemes like there are 1.13 records in database per 1 crime.
    


```python
tmp = df.groupby("INCIDENT_NUMBER")["YEAR"].count().sort_values(ascending = False)
tmp.head(10)
```




    INCIDENT_NUMBER
    I162030584    13
    I152080623    11
    I172013170    10
    I172096394    10
    I182065208    10
    I162098170     9
    I172056883     9
    I162001871     9
    I172054429     9
    I172022524     9
    Name: YEAR, dtype: int64




```python
tmp.value_counts()
```




    1     261791
    2      22056
    3       4314
    4       1343
    5        445
    6        137
    7         47
    8         12
    9          6
    10         3
    13         1
    11         1
    Name: YEAR, dtype: int64




```python
print('It occurs that {}% of our events are "duplicated" at least 2 times.'.format(round(100*(282517 - 254996) / 282517),2))
```

    It occurs that 10% of our events are "duplicated" at least 2 times.
    


```python
df[df["INCIDENT_NUMBER"] == "I162030584"]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>INCIDENT_NUMBER</th>
      <th>OFFENSE_CODE</th>
      <th>OFFENSE_CODE_GROUP</th>
      <th>OFFENSE_DESCRIPTION</th>
      <th>DISTRICT</th>
      <th>REPORTING_AREA</th>
      <th>SHOOTING</th>
      <th>OCCURRED_ON_DATE</th>
      <th>YEAR</th>
      <th>MONTH</th>
      <th>DAY_OF_WEEK</th>
      <th>HOUR</th>
      <th>UCR_PART</th>
      <th>STREET</th>
      <th>Lat</th>
      <th>Long</th>
      <th>Location</th>
      <th>DATE</th>
      <th>YEARMONTH</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>246401</th>
      <td>I162030584</td>
      <td>423</td>
      <td>Aggravated Assault</td>
      <td>ASSAULT - AGGRAVATED</td>
      <td>C11</td>
      <td>243</td>
      <td>N</td>
      <td>20-04-2016 11:07</td>
      <td>2016</td>
      <td>4</td>
      <td>Wednesday</td>
      <td>11</td>
      <td>Part One</td>
      <td>TRESCOTT ST</td>
      <td>42.3158</td>
      <td>-71.060521</td>
      <td>(42.31580044, -71.06052053)</td>
      <td>20-04-2016</td>
      <td>20-04-2</td>
    </tr>
    <tr>
      <th>246402</th>
      <td>I162030584</td>
      <td>802</td>
      <td>Simple Assault</td>
      <td>ASSAULT SIMPLE - BATTERY</td>
      <td>C11</td>
      <td>243</td>
      <td>N</td>
      <td>20-04-2016 11:07</td>
      <td>2016</td>
      <td>4</td>
      <td>Wednesday</td>
      <td>11</td>
      <td>Part Two</td>
      <td>TRESCOTT ST</td>
      <td>42.3158</td>
      <td>-71.060521</td>
      <td>(42.31580044, -71.06052053)</td>
      <td>20-04-2016</td>
      <td>20-04-2</td>
    </tr>
    <tr>
      <th>246403</th>
      <td>I162030584</td>
      <td>1501</td>
      <td>Firearm Violations</td>
      <td>WEAPON - FIREARM - CARRYING / POSSESSING, ETC</td>
      <td>C11</td>
      <td>243</td>
      <td>N</td>
      <td>20-04-2016 11:07</td>
      <td>2016</td>
      <td>4</td>
      <td>Wednesday</td>
      <td>11</td>
      <td>Part Two</td>
      <td>TRESCOTT ST</td>
      <td>42.3158</td>
      <td>-71.060521</td>
      <td>(42.31580044, -71.06052053)</td>
      <td>20-04-2016</td>
      <td>20-04-2</td>
    </tr>
    <tr>
      <th>246404</th>
      <td>I162030584</td>
      <td>1504</td>
      <td>Other</td>
      <td>WEAPON - OTHER - OTHER VIOLATION</td>
      <td>C11</td>
      <td>243</td>
      <td>N</td>
      <td>20-04-2016 11:07</td>
      <td>2016</td>
      <td>4</td>
      <td>Wednesday</td>
      <td>11</td>
      <td>Part Two</td>
      <td>TRESCOTT ST</td>
      <td>42.3158</td>
      <td>-71.060521</td>
      <td>(42.31580044, -71.06052053)</td>
      <td>20-04-2016</td>
      <td>20-04-2</td>
    </tr>
    <tr>
      <th>246405</th>
      <td>I162030584</td>
      <td>1843</td>
      <td>Drug Violation</td>
      <td>DRUGS - POSS CLASS B - INTENT TO MFR DIST DISP</td>
      <td>C11</td>
      <td>243</td>
      <td>N</td>
      <td>20-04-2016 11:07</td>
      <td>2016</td>
      <td>4</td>
      <td>Wednesday</td>
      <td>11</td>
      <td>Part Two</td>
      <td>TRESCOTT ST</td>
      <td>42.3158</td>
      <td>-71.060521</td>
      <td>(42.31580044, -71.06052053)</td>
      <td>20-04-2016</td>
      <td>20-04-2</td>
    </tr>
    <tr>
      <th>246406</th>
      <td>I162030584</td>
      <td>2010</td>
      <td>HOME INVASION</td>
      <td>HOME INVASION</td>
      <td>C11</td>
      <td>243</td>
      <td>N</td>
      <td>20-04-2016 11:07</td>
      <td>2016</td>
      <td>4</td>
      <td>Wednesday</td>
      <td>11</td>
      <td>NaN</td>
      <td>TRESCOTT ST</td>
      <td>42.3158</td>
      <td>-71.060521</td>
      <td>(42.31580044, -71.06052053)</td>
      <td>20-04-2016</td>
      <td>20-04-2</td>
    </tr>
    <tr>
      <th>246407</th>
      <td>I162030584</td>
      <td>371</td>
      <td>Robbery</td>
      <td>ROBBERY - HOME INVASION</td>
      <td>C11</td>
      <td>243</td>
      <td>N</td>
      <td>20-04-2016 11:07</td>
      <td>2016</td>
      <td>4</td>
      <td>Wednesday</td>
      <td>11</td>
      <td>Part One</td>
      <td>TRESCOTT ST</td>
      <td>42.3158</td>
      <td>-71.060521</td>
      <td>(42.31580044, -71.06052053)</td>
      <td>20-04-2016</td>
      <td>20-04-2</td>
    </tr>
    <tr>
      <th>246408</th>
      <td>I162030584</td>
      <td>1106</td>
      <td>Confidence Games</td>
      <td>FRAUD - CREDIT CARD / ATM FRAUD</td>
      <td>C11</td>
      <td>243</td>
      <td>N</td>
      <td>20-04-2016 11:07</td>
      <td>2016</td>
      <td>4</td>
      <td>Wednesday</td>
      <td>11</td>
      <td>Part Two</td>
      <td>TRESCOTT ST</td>
      <td>42.3158</td>
      <td>-71.060521</td>
      <td>(42.31580044, -71.06052053)</td>
      <td>20-04-2016</td>
      <td>20-04-2</td>
    </tr>
    <tr>
      <th>246409</th>
      <td>I162030584</td>
      <td>1300</td>
      <td>Recovered Stolen Property</td>
      <td>STOLEN PROPERTY - BUYING / RECEIVING / POSSESSING</td>
      <td>C11</td>
      <td>243</td>
      <td>N</td>
      <td>20-04-2016 11:07</td>
      <td>2016</td>
      <td>4</td>
      <td>Wednesday</td>
      <td>11</td>
      <td>Part Two</td>
      <td>TRESCOTT ST</td>
      <td>42.3158</td>
      <td>-71.060521</td>
      <td>(42.31580044, -71.06052053)</td>
      <td>20-04-2016</td>
      <td>20-04-2</td>
    </tr>
    <tr>
      <th>246410</th>
      <td>I162030584</td>
      <td>1510</td>
      <td>Firearm Violations</td>
      <td>WEAPON - FIREARM - OTHER VIOLATION</td>
      <td>C11</td>
      <td>243</td>
      <td>N</td>
      <td>20-04-2016 11:07</td>
      <td>2016</td>
      <td>4</td>
      <td>Wednesday</td>
      <td>11</td>
      <td>Part Two</td>
      <td>TRESCOTT ST</td>
      <td>42.3158</td>
      <td>-71.060521</td>
      <td>(42.31580044, -71.06052053)</td>
      <td>20-04-2016</td>
      <td>20-04-2</td>
    </tr>
    <tr>
      <th>246411</th>
      <td>I162030584</td>
      <td>2660</td>
      <td>Other</td>
      <td>OTHER OFFENSE</td>
      <td>C11</td>
      <td>243</td>
      <td>N</td>
      <td>20-04-2016 11:07</td>
      <td>2016</td>
      <td>4</td>
      <td>Wednesday</td>
      <td>11</td>
      <td>Part Two</td>
      <td>TRESCOTT ST</td>
      <td>42.3158</td>
      <td>-71.060521</td>
      <td>(42.31580044, -71.06052053)</td>
      <td>20-04-2016</td>
      <td>20-04-2</td>
    </tr>
    <tr>
      <th>246412</th>
      <td>I162030584</td>
      <td>3125</td>
      <td>Warrant Arrests</td>
      <td>WARRANT ARREST</td>
      <td>C11</td>
      <td>243</td>
      <td>N</td>
      <td>20-04-2016 11:07</td>
      <td>2016</td>
      <td>4</td>
      <td>Wednesday</td>
      <td>11</td>
      <td>Part Three</td>
      <td>TRESCOTT ST</td>
      <td>42.3158</td>
      <td>-71.060521</td>
      <td>(42.31580044, -71.06052053)</td>
      <td>20-04-2016</td>
      <td>20-04-2</td>
    </tr>
    <tr>
      <th>246413</th>
      <td>I162030584</td>
      <td>3170</td>
      <td>Other</td>
      <td>INTIMIDATING WITNESS</td>
      <td>C11</td>
      <td>243</td>
      <td>N</td>
      <td>20-04-2016 11:07</td>
      <td>2016</td>
      <td>4</td>
      <td>Wednesday</td>
      <td>11</td>
      <td>Part Three</td>
      <td>TRESCOTT ST</td>
      <td>42.3158</td>
      <td>-71.060521</td>
      <td>(42.31580044, -71.06052053)</td>
      <td>20-04-2016</td>
      <td>20-04-2</td>
    </tr>
  </tbody>
</table>
</div>




```python
df[df["INCIDENT_NUMBER"] == "I152080623"]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>INCIDENT_NUMBER</th>
      <th>OFFENSE_CODE</th>
      <th>OFFENSE_CODE_GROUP</th>
      <th>OFFENSE_DESCRIPTION</th>
      <th>DISTRICT</th>
      <th>REPORTING_AREA</th>
      <th>SHOOTING</th>
      <th>OCCURRED_ON_DATE</th>
      <th>YEAR</th>
      <th>MONTH</th>
      <th>DAY_OF_WEEK</th>
      <th>HOUR</th>
      <th>UCR_PART</th>
      <th>STREET</th>
      <th>Lat</th>
      <th>Long</th>
      <th>Location</th>
      <th>DATE</th>
      <th>YEARMONTH</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>299552</th>
      <td>I152080623</td>
      <td>413</td>
      <td>Aggravated Assault</td>
      <td>ASSAULT - AGGRAVATED - BATTERY</td>
      <td>D14</td>
      <td>776</td>
      <td>N</td>
      <td>27-09-2015 20:29</td>
      <td>2015</td>
      <td>9</td>
      <td>Sunday</td>
      <td>20</td>
      <td>Part One</td>
      <td>UNION ST</td>
      <td>42.34568</td>
      <td>-71.150742</td>
      <td>(42.34568023, -71.15074209)</td>
      <td>27-09-2015</td>
      <td>27-09-2</td>
    </tr>
    <tr>
      <th>299553</th>
      <td>I152080623</td>
      <td>423</td>
      <td>Aggravated Assault</td>
      <td>ASSAULT - AGGRAVATED</td>
      <td>D14</td>
      <td>776</td>
      <td>N</td>
      <td>27-09-2015 20:29</td>
      <td>2015</td>
      <td>9</td>
      <td>Sunday</td>
      <td>20</td>
      <td>Part One</td>
      <td>UNION ST</td>
      <td>42.34568</td>
      <td>-71.150742</td>
      <td>(42.34568023, -71.15074209)</td>
      <td>27-09-2015</td>
      <td>27-09-2</td>
    </tr>
    <tr>
      <th>299554</th>
      <td>I152080623</td>
      <td>802</td>
      <td>Simple Assault</td>
      <td>ASSAULT SIMPLE - BATTERY</td>
      <td>D14</td>
      <td>776</td>
      <td>N</td>
      <td>27-09-2015 20:29</td>
      <td>2015</td>
      <td>9</td>
      <td>Sunday</td>
      <td>20</td>
      <td>Part Two</td>
      <td>UNION ST</td>
      <td>42.34568</td>
      <td>-71.150742</td>
      <td>(42.34568023, -71.15074209)</td>
      <td>27-09-2015</td>
      <td>27-09-2</td>
    </tr>
    <tr>
      <th>299555</th>
      <td>I152080623</td>
      <td>1846</td>
      <td>Drug Violation</td>
      <td>DRUGS - POSS CLASS E</td>
      <td>D14</td>
      <td>776</td>
      <td>N</td>
      <td>27-09-2015 20:29</td>
      <td>2015</td>
      <td>9</td>
      <td>Sunday</td>
      <td>20</td>
      <td>Part Two</td>
      <td>UNION ST</td>
      <td>42.34568</td>
      <td>-71.150742</td>
      <td>(42.34568023, -71.15074209)</td>
      <td>27-09-2015</td>
      <td>27-09-2</td>
    </tr>
    <tr>
      <th>299556</th>
      <td>I152080623</td>
      <td>2511</td>
      <td>Other</td>
      <td>KIDNAPPING - ENTICING OR ATTEMPTED</td>
      <td>D14</td>
      <td>776</td>
      <td>N</td>
      <td>27-09-2015 20:29</td>
      <td>2015</td>
      <td>9</td>
      <td>Sunday</td>
      <td>20</td>
      <td>Part Two</td>
      <td>UNION ST</td>
      <td>42.34568</td>
      <td>-71.150742</td>
      <td>(42.34568023, -71.15074209)</td>
      <td>27-09-2015</td>
      <td>27-09-2</td>
    </tr>
    <tr>
      <th>299557</th>
      <td>I152080623</td>
      <td>2660</td>
      <td>Other</td>
      <td>OTHER OFFENSE</td>
      <td>D14</td>
      <td>776</td>
      <td>N</td>
      <td>27-09-2015 20:29</td>
      <td>2015</td>
      <td>9</td>
      <td>Sunday</td>
      <td>20</td>
      <td>Part Two</td>
      <td>UNION ST</td>
      <td>42.34568</td>
      <td>-71.150742</td>
      <td>(42.34568023, -71.15074209)</td>
      <td>27-09-2015</td>
      <td>27-09-2</td>
    </tr>
    <tr>
      <th>299558</th>
      <td>I152080623</td>
      <td>381</td>
      <td>Robbery</td>
      <td>ROBBERY - CAR JACKING</td>
      <td>D14</td>
      <td>776</td>
      <td>N</td>
      <td>27-09-2015 20:29</td>
      <td>2015</td>
      <td>9</td>
      <td>Sunday</td>
      <td>20</td>
      <td>Part One</td>
      <td>UNION ST</td>
      <td>42.34568</td>
      <td>-71.150742</td>
      <td>(42.34568023, -71.15074209)</td>
      <td>27-09-2015</td>
      <td>27-09-2</td>
    </tr>
    <tr>
      <th>299559</th>
      <td>I152080623</td>
      <td>1402</td>
      <td>Vandalism</td>
      <td>VANDALISM</td>
      <td>D14</td>
      <td>776</td>
      <td>N</td>
      <td>27-09-2015 20:29</td>
      <td>2015</td>
      <td>9</td>
      <td>Sunday</td>
      <td>20</td>
      <td>Part Two</td>
      <td>UNION ST</td>
      <td>42.34568</td>
      <td>-71.150742</td>
      <td>(42.34568023, -71.15074209)</td>
      <td>27-09-2015</td>
      <td>27-09-2</td>
    </tr>
    <tr>
      <th>299560</th>
      <td>I152080623</td>
      <td>1504</td>
      <td>Other</td>
      <td>WEAPON - OTHER - OTHER VIOLATION</td>
      <td>D14</td>
      <td>776</td>
      <td>N</td>
      <td>27-09-2015 20:29</td>
      <td>2015</td>
      <td>9</td>
      <td>Sunday</td>
      <td>20</td>
      <td>Part Two</td>
      <td>UNION ST</td>
      <td>42.34568</td>
      <td>-71.150742</td>
      <td>(42.34568023, -71.15074209)</td>
      <td>27-09-2015</td>
      <td>27-09-2</td>
    </tr>
    <tr>
      <th>299561</th>
      <td>I152080623</td>
      <td>1844</td>
      <td>Drug Violation</td>
      <td>DRUGS - POSS CLASS C</td>
      <td>D14</td>
      <td>776</td>
      <td>N</td>
      <td>27-09-2015 20:29</td>
      <td>2015</td>
      <td>9</td>
      <td>Sunday</td>
      <td>20</td>
      <td>Part Two</td>
      <td>UNION ST</td>
      <td>42.34568</td>
      <td>-71.150742</td>
      <td>(42.34568023, -71.15074209)</td>
      <td>27-09-2015</td>
      <td>27-09-2</td>
    </tr>
    <tr>
      <th>299562</th>
      <td>I152080623</td>
      <td>1849</td>
      <td>Drug Violation</td>
      <td>DRUGS - POSS CLASS B - COCAINE, ETC.</td>
      <td>D14</td>
      <td>776</td>
      <td>N</td>
      <td>27-09-2015 20:29</td>
      <td>2015</td>
      <td>9</td>
      <td>Sunday</td>
      <td>20</td>
      <td>Part Two</td>
      <td>UNION ST</td>
      <td>42.34568</td>
      <td>-71.150742</td>
      <td>(42.34568023, -71.15074209)</td>
      <td>27-09-2015</td>
      <td>27-09-2</td>
    </tr>
  </tbody>
</table>
</div>




```python
timeOccurencesNormal = df[['INCIDENT_NUMBER','OCCURRED_ON_DATE', 'YEAR', 'MONTH', 'SHOOTING',
                           'DAY_OF_WEEK', 'HOUR', 'DATE', 'YEARMONTH']]
timeOccurencesDedup  = df[['INCIDENT_NUMBER','OCCURRED_ON_DATE', 'YEAR', 'MONTH', 'SHOOTING',
                           'DAY_OF_WEEK', 'HOUR', 'DATE', 'YEARMONTH']].drop_duplicates()

print('Sanity check for duplicates: ({}, {})'.format(df['INCIDENT_NUMBER'].nunique(), timeOccurencesDedup.shape[0]))
```

    Sanity check for duplicates: (290156, 290156)
    


```python
fig, axes = plt.subplots(nrows = 3, ncols = 2, figsize = (18, 10))

sns.countplot(timeOccurencesNormal["YEAR"], color='lightblue', ax = axes[0,0] )
axes[0,0].set_title("Number of crimes")
sns.countplot(timeOccurencesNormal["DAY_OF_WEEK"], color='lightgreen', ax = axes[1,0])
axes[1,0].set_title("Number of crimes")
sns.countplot(timeOccurencesNormal["HOUR"], color = 'orange', ax = axes[2,0])
axes[2,0].set_title("Number of crimes")

sns.countplot(timeOccurencesDedup["YEAR"], color='lightblue', ax = axes[0,1] )
axes[0,1].set_title("Number of crimes (deduplicated)")
sns.countplot(timeOccurencesDedup["DAY_OF_WEEK"], color='lightgreen', ax = axes[1,1] )
axes[1,1].set_title("Number of crimes (deduplicated)")
sns.countplot(timeOccurencesDedup["HOUR"], color = 'orange', ax = axes[2,1] )
axes[2,1].set_title("Number of crimes (deduplicated)")

plt.tight_layout()
```


![png](output_16_0.png)



```python
fig, axes = plt.subplots(nrows = 1, ncols = 2, figsize = (18, 7))

sns.heatmap(pd.pivot_table(data = timeOccurencesNormal, index = "DAY_OF_WEEK", 
                              columns = "HOUR", values = "INCIDENT_NUMBER", aggfunc = 'count'), 
               cmap = 'Reds', ax = axes[0])
sns.heatmap(pd.pivot_table(data = timeOccurencesDedup, index = "DAY_OF_WEEK", 
                              columns = "HOUR", values = "INCIDENT_NUMBER", aggfunc = 'count')
               , cmap = 'Reds', ax = axes[1])
```




    <matplotlib.axes._subplots.AxesSubplot at 0x1f5276a3b70>




![png](output_17_1.png)



```python
fig = plt.figure(figsize=(18,6))

axes = fig.add_axes([0.1,0.1,0.8,0.8])
axes.plot(timeOccurencesNormal.groupby('DATE').count(), 
          c = 'blue', label = "Original data")
axes.plot(timeOccurencesDedup.groupby('DATE').count(), 
          c = 'green', label = "Dedup data")
plt.xticks(rotation = 90)
plt.legend()
axes.set_title("Number of crimes in a day")
axes.set_ylabel("Number of crimes")

labelsX = timeOccurencesNormal.groupby('DATE').count().index[::30]
plt.xticks(labelsX, rotation='vertical')

#I've got duplicated legend here, so I used remedy:
# https://stackoverflow.com/questions/19385639/duplicate-items-in-legend-in-matplotlib
handles, labels = axes.get_legend_handles_labels() 
i = np.arange(len(labels))
filter = np.array([])
unique_labels = list(set(labels))
for ul in unique_labels:
    filter = np.append(filter, [i[np.array(labels) == ul][0]]) 
    
handles = [handles[int(f)] for f in filter] 
labels = [labels[int(f)] for f in filter]
axes.legend(handles, labels) 
```




    <matplotlib.legend.Legend at 0x1f5204f0400>




![png](output_18_1.png)



```python
fig = plt.figure(figsize=(18,6))

axes = fig.add_axes([0.1,0.1,0.8,0.8])
axes.plot(timeOccurencesNormal.groupby('YEARMONTH').count(), 
          c = 'blue', label = "Original data")
axes.plot(timeOccurencesDedup.groupby('YEARMONTH').count(), 
          c = 'green', label = "Dedup data")
plt.xticks(rotation = 90)
plt.legend()
axes.set_title("Number of crimes in a month")
axes.set_ylabel("Number of crimes")

#I've got duplicated legend here, so I used remedy:
# https://stackoverflow.com/questions/19385639/duplicate-items-in-legend-in-matplotlib
handles, labels = axes.get_legend_handles_labels() 
i = np.arange(len(labels))
filter = np.array([])
unique_labels = list(set(labels))
for ul in unique_labels:
    filter = np.append(filter, [i[np.array(labels) == ul][0]]) 
    
handles = [handles[int(f)] for f in filter] 
labels = [labels[int(f)] for f in filter]
axes.legend(handles, labels)  
```




    <matplotlib.legend.Legend at 0x1f52c961c88>




![png](output_19_1.png)



```python
print('We have {}% of shooting crimes in all events (deduplicated situation).'.format(
    round(100*timeOccurencesDedup[timeOccurencesDedup['SHOOTING'] == 'Y'].shape[0]/timeOccurencesDedup.shape[0],2)))
```

    We have 0.22% of shooting crimes in all events (deduplicated situation).
    


```python
fig = plt.figure(figsize=(18,6))

axes = fig.add_axes([0.1,0.1,0.8,0.8])
axes.plot(timeOccurencesNormal[timeOccurencesNormal["SHOOTING"] == "Y"].groupby('DATE').count(), 
          c = 'lightblue', label = "Original data")
axes.plot(timeOccurencesDedup[timeOccurencesDedup["SHOOTING"] == "Y"].groupby('DATE').count(), 
          c = 'black', label = "Dedup data")
plt.xticks(rotation = 90)
plt.legend()
axes.set_title("Shooting crimes")
axes.set_ylabel("Number of crimes with shooting")

labelsX = timeOccurencesNormal[timeOccurencesNormal["SHOOTING"] == "Y"].groupby('DATE').count().index[::30]
plt.xticks(labelsX, rotation='vertical')

#I've got duplicated legend here, so I used remedy:
# https://stackoverflow.com/questions/19385639/duplicate-items-in-legend-in-matplotlib
handles, labels = axes.get_legend_handles_labels() 
i = np.arange(len(labels))
filter = np.array([])
unique_labels = list(set(labels))
for ul in unique_labels:
    filter = np.append(filter, [i[np.array(labels) == ul][0]]) 
    
handles = [handles[int(f)] for f in filter] 
labels = [labels[int(f)] for f in filter]
axes.legend(handles, labels) 
```




    <matplotlib.legend.Legend at 0x1f52cca7710>




![png](output_21_1.png)



```python
fig = plt.figure(figsize=(18,6))

axes = fig.add_axes([0.1,0.1,0.8,0.8])
axes.plot(timeOccurencesNormal[timeOccurencesNormal["SHOOTING"] == "Y"].groupby('YEARMONTH').count(), 
          c = 'blue', label = "Original data", marker = "o")
axes.plot(timeOccurencesDedup[timeOccurencesDedup["SHOOTING"] == "Y"].groupby('YEARMONTH').count(), 
          c = 'green', label = "Dedup data", marker="o")
plt.xticks(rotation = 90)
plt.legend()
axes.set_title("Shooting crimes")
axes.set_ylabel("Number of crimes with shooting")

#I've got duplicated legend here, so I used remedy:
# https://stackoverflow.com/questions/19385639/duplicate-items-in-legend-in-matplotlib
handles, labels = axes.get_legend_handles_labels() 
i = np.arange(len(labels))
filter = np.array([])
unique_labels = list(set(labels))
for ul in unique_labels:
    filter = np.append(filter, [i[np.array(labels) == ul][0]]) 
    
handles = [handles[int(f)] for f in filter] 
labels = [labels[int(f)] for f in filter]
axes.legend(handles, labels) 
```




    <matplotlib.legend.Legend at 0x1f530102048>




![png](output_22_1.png)



```python
fig, axes = plt.subplots(nrows = 1, ncols = 2, figsize = (18, 7))

sns.heatmap(pd.pivot_table(data = timeOccurencesNormal[timeOccurencesNormal["SHOOTING"] == "Y"], index = "DAY_OF_WEEK", 
                              columns = "HOUR", values = "INCIDENT_NUMBER", aggfunc = 'count'), 
               cmap = 'Reds', ax = axes[0])
sns.heatmap(pd.pivot_table(data = timeOccurencesDedup[timeOccurencesNormal["SHOOTING"] == "Y"], index = "DAY_OF_WEEK", 
                              columns = "HOUR", values = "INCIDENT_NUMBER", aggfunc = 'count')
               , cmap = 'Reds', ax = axes[1])

```

    C:\Users\D Navya\Anaconda3\lib\site-packages\ipykernel_launcher.py:6: UserWarning: Boolean Series key will be reindexed to match DataFrame index.
      
    




    <matplotlib.axes._subplots.AxesSubplot at 0x1f5328721d0>




![png](output_23_2.png)



```python
locationOccurencesNormal = df[['INCIDENT_NUMBER','DISTRICT', 'REPORTING_AREA', 'SHOOTING','Lat', 'Long']]
locationOccurencesDedup  = df[['INCIDENT_NUMBER','DISTRICT', 'REPORTING_AREA', 'SHOOTING','Lat', 'Long']].drop_duplicates()
print('Sanity check for duplicates: ({}, {})'.format(df['INCIDENT_NUMBER'].nunique(), locationOccurencesDedup.shape[0]))

```

    Sanity check for duplicates: (290156, 290156)
    


```python
# Plot districts
fig, axes = plt.subplots(nrows = 1, ncols = 2, figsize = (18, 7))
sns.scatterplot(y='Lat',
                x='Long',
                hue='DISTRICT',
                alpha=0.01,
                data=locationOccurencesNormal, 
                ax = axes[0])
#plt.ylim(locationOccurencesNormal['Long'].max(), locationOccurencesNormal['Long'].min())
sns.scatterplot(y='Lat',
                x='Long',
                hue='DISTRICT',
                alpha=0.01,
                data=locationOccurencesDedup, 
                ax = axes[1])
```




    <matplotlib.axes._subplots.AxesSubplot at 0x1f533e266d8>




![png](output_25_1.png)



```python
fig, axes = plt.subplots(nrows = 1, ncols = 2, figsize = (18, 7))
sns.scatterplot(y = 'Lat',
                x = 'Long',
                alpha = 0.3,
                data = locationOccurencesNormal[locationOccurencesNormal["SHOOTING"]=="Y"], 
                ax = axes[0])
axes[0].set_title("Crime locations")
sns.scatterplot(y = 'Lat',
                x = 'Long',
                alpha = 0.3,
                data = locationOccurencesDedup[locationOccurencesDedup["SHOOTING"]=="Y"], 
                ax = axes[1])
axes[1].set_title("Crime locations (deduplicated)")
```




    Text(0.5, 1.0, 'Crime locations (deduplicated)')




![png](output_26_1.png)



```python
locationTimeOccurencesDedup = df[['INCIDENT_NUMBER', 'SHOOTING','Lat', 'Long', 'DAY_OF_WEEK', 'HOUR']].drop_duplicates()
print('Sanity check for duplicates: ({}, {})'.format(df['INCIDENT_NUMBER'].nunique(), locationOccurencesDedup.shape[0]))
```

    Sanity check for duplicates: (290156, 290156)
    


```python
fig = plt.figure(figsize=(18,10))
g = sns.FacetGrid(data = locationTimeOccurencesDedup[(locationTimeOccurencesDedup['HOUR'] >= 1) & (locationTimeOccurencesDedup['HOUR'] <= 7)],
                                                  row = 'HOUR', col = 'DAY_OF_WEEK')
g = g.map(sns.scatterplot, 'Long', 'Lat', alpha=0.03)
```


    <Figure size 1296x720 with 0 Axes>



![png](output_28_1.png)



```python

```
